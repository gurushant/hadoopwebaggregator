/**
 * 
 */
function CreateXmlHttpObject()
  { 
  var objXMLHttp=null
  if (window.XMLHttpRequest)
  {
  objXMLHttp=new XMLHttpRequest()
  }
  else if (window.ActiveXObject)
  {
  objXMLHttp=new ActiveXObject("Microsoft.XMLHTTP")
  }
  return objXMLHttp
  }