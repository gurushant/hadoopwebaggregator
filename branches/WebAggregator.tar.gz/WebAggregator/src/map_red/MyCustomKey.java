package map_red;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

class MyCustomKey implements WritableComparable<MyCustomKey> 
{ 
	Text keyField_0=null;
	Text keyField_1=null;
	public MyCustomKey(String keyField_0,String keyField_1)
	{
		this.keyField_0=new Text(keyField_0);
		this.keyField_1=new Text(keyField_1);
	}
	public MyCustomKey()
	{
		keyField_0=new Text();
		keyField_1=new Text();

	}
	public void setkeyField_0(Text keyField_0)
	{
		this.keyField_0=keyField_0;
	}
	public Text getkeyField_0()
	{
		return keyField_0;
	}
	public void setkeyField_1(Text keyField_1)
	{
		this.keyField_1=keyField_1;
	}
	public Text getkeyField_1()
	{
		return keyField_1;
	}
	public String toString()
	{
		return keyField_0.toString()+keyField_1.toString();
	}
	public void readFields(DataInput in) throws IOException {
		keyField_0.readFields(in);
		keyField_1.readFields(in);
	}
	public void write(DataOutput out) throws IOException {
		keyField_0.write(out);
		keyField_1.write(out);
	}
	public int compareTo(MyCustomKey key) {
		int res=0;
		res=keyField_0.compareTo(key.keyField_0);
		if(res==0)
			res=keyField_1.compareTo(key.keyField_1);
		return res;
	}
}
