package map_red;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

class MyCustomValue implements Writable 
{ 
	Text valField_0=null;
	Text valField_1=null;
	public MyCustomValue(String valField_0,String valField_1)
	{
		this.valField_0=new Text(valField_0);
		this.valField_1=new Text(valField_1);
	}
	public MyCustomValue()
	{
		valField_0=new Text();
		valField_1=new Text();

	}
	public void setvalField_0(Text valField_0)
	{
		this.valField_0=valField_0;
	}
	public Text getvalField_0()
	{
		return valField_0;
	}
	public void setvalField_1(Text valField_1)
	{
		this.valField_1=valField_1;
	}
	public Text getvalField_1()
	{
		return valField_1;
	}
	public String toString()
	{
		return valField_0.toString()+valField_1.toString();
	}
	public void readFields(DataInput in) throws IOException {
		valField_0.readFields(in);
		valField_1.readFields(in);
	}
	public void write(DataOutput out) throws IOException {
		valField_0.write(out);
		valField_1.write(out);
	}
}
