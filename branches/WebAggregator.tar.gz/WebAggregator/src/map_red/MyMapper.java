package map_red;

import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MyMapper extends Mapper<LongWritable, Text, Text, Text> {

	public void map(LongWritable ikey, Text ivalue, Context context)
			throws IOException, InterruptedException {
		String seperator=MapReduceDriver.getSeperator();
		String value[]=ivalue.toString().split(seperator);
		String keys=MapReduceDriver.getKeys();
		String values=MapReduceDriver.getValues();
		String keyIndex[]=keys.split(",");
		String valIndex[]=values.split(",");
		
		//take index of key,valu and pass to custom key and customvalye class.
	}

}
