package map_red;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.MRJobConfig;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class MapReduceDriver {

	public static final String SCRIPT_PATH="/home/gurushant/gurushant/scripts/";
	public static final String HADOOP_PATH="/home/gurushant/gurushant/data/personal/sw/hadoop-2.2.0/bin/";
	private String inputPath=null;
	private static String seperator=null,keys=null,values=null,reducerCnt=null;

	public static void main(String[] args) throws Exception {

	}
	private void executeHadoopCommand(final String command)
	{
		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				ProcessBuilder process=new ProcessBuilder(command);
				try {
					process.start().waitFor();

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}).start();
	}

	public static String getSeperator()
	{
		return seperator;
	}
	public static String getKeys()
	{
		return keys;
	}

	public static String getValues()
	{
		return values;
	}



	private File createFile(String content,String name)
	{
		try
		{
			File file=new File(SCRIPT_PATH+name);
			file.createNewFile();
			file.setExecutable(true);
			file.setWritable(true);
			file.setReadable(true);

			FileOutputStream fout=new FileOutputStream(file);
			fout.write("#/bin/sh\n".getBytes());
			fout.write(content.getBytes());
			fout.close();
			return file;
		}
		catch(Exception ex)
		{

			ex.printStackTrace();
			return null;
		}
	}

	public void submitFile(HashMap<String, String> param)
	{
		try
		{
			File scriptFile=null;
			seperator=param.get("seperator");
			keys=param.get("keys");
			values=param.get("values");
			reducerCnt=param.get("no_of_reducer");

			inputPath=param.get("input_file");

			//remove existing file from hdfs
			scriptFile=createFile(HADOOP_PATH+"hdfs dfs -rm -r /data/"+param.get("file_name"), "remove.sh");
			executeHadoopCommand(scriptFile.getAbsolutePath());
			//put file in hdfs
			scriptFile=createFile(HADOOP_PATH+"hdfs dfs -put "+inputPath +" /data", "addFile.sh");
			executeHadoopCommand(scriptFile.getAbsolutePath());
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	public void submitJob(HashMap<String, String> param)
	{
		try
		{
			File scriptFile=null;
			seperator=param.get("seperator");
			keys=param.get("keys");
			values=param.get("values");
			reducerCnt=param.get("no_of_reducer");

			//create custom keys and values
	//		new CustomKeyGenerator().createCustomKey(keys.split(",").length);
	//		new CustomValueGenerator().createCustomValue(values.split(",").length);

			Configuration conf = new Configuration();
			conf.set("mapreduce.cluster.local.dir", "/home/gurushant/gurushant");
			Job job = Job.getInstance(conf, "JobName");
			job.setJarByClass(map_red.MapReduceDriver.class);
			inputPath=param.get("input_file");

			//remove existing file from hdfs
			scriptFile=createFile(HADOOP_PATH+"hdfs -dfs -rm -r /data"+param.get("file_name"), "remove.sh");
			executeHadoopCommand(scriptFile.getAbsolutePath());
			//put file in hdfs
			scriptFile=createFile(HADOOP_PATH+"hdfs -dfs put "+inputPath +" /data", "addFile.sh");
			executeHadoopCommand(scriptFile.getAbsolutePath());

			// TODO: specify a mapper
			job.setMapperClass(MyMapper.class);
			job.setNumReduceTasks(Integer.parseInt(reducerCnt));
			// TODO: specify a reducer
			//job.setReducerClass(Reducer.class);
			job.setMapOutputKeyClass(MyCustomKey.class);
			// TODO: specify output types
			job.setOutputKeyClass(MyCustomKey.class);
			job.setOutputValueClass(MyCustomValue.class);

			// TODO: specify input and output DIRECTORIES (not files)
			FileInputFormat.setInputPaths(job, new Path("/data/input.txt"));
			FileOutputFormat.setOutputPath(job, new Path("/data/out"));

			if (!job.waitForCompletion(true))
				return;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

}
