package servlets;


import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import map_red.MapReduceDriver;

import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.hadoop.test.MapredTestDriver;
import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.FileItemFactory;
import org.apache.tomcat.util.http.fileupload.RequestContext;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

import util.MapReduceJobSetup;

/**
 * Servlet implementation class RunMRJob
 */
@WebServlet("/servlets/RunMRJob")
public class RunMRJob extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String IN_PATH="/home/gurushant/gurushant/input_to_mr/";
    /**
     * Default constructor. 
     */
    public RunMRJob() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("in do get");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HashMap<String, String> param=new HashMap<String, String>();
		response.setContentType("text/html");
		System.out.println(request.getContentType());
		 boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		 byte buffer[]=null;
		 if(isMultipart)
		 {
			 
	           FileItemFactory factory = new DiskFileItemFactory();
	           ServletFileUpload upload = new ServletFileUpload(factory);  
	           try
	           {
	        	   List<org.apache.commons.fileupload.FileItem> multiparts = new org.apache.commons.fileupload.servlet.ServletFileUpload(
                           new org.apache.commons.fileupload.disk.DiskFileItemFactory()).
                           parseRequest(request);
	        	   for(org.apache.commons.fileupload.FileItem item:multiparts)
	        	   {
	        		   System.out.println("item="+item.getFieldName());
	        		   String str=new String(item.getString());
	        		   System.out.println("item="+str);
	        		   if(!item.isFormField())
	        		   {
	        			   FileOutputStream fout=null;
	        			   String filename = item.getName();
	                       InputStream filecontent = item.getInputStream();
	                       buffer=new byte[filecontent.available()];
	                       filecontent.read(buffer);
	                       String s = new String(buffer);
	                       //System.out.println("s="+s);
	                       fout= new FileOutputStream(IN_PATH+filename);
	                       fout.write(buffer);
	                       fout.close();
	                       param.put("input_file", IN_PATH+filename);
	                       param.put("file_name", filename);
	        		   }
	        		   else
	        		   {
	        			   param.put(item.getFieldName(), item.getString());
	        		   }
	        	   }
	        	   
	        	   new MapReduceJobSetup().submitFile(param);
 
	           }
	           catch(Exception ex)
	           {
	        	   ex.printStackTrace();
	           }
		 }
		 
		
	}

}
