package util;
import java.util.Vector;


public class CustomValueGenerator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new CustomValueGenerator().createCustomValue(2);
	}
	
	String createCustomValue(int fieldCount)
	{
		StringBuilder paramConstructor=null;
		int cnt=0;
		Vector<String> fieldVector=new Vector<String>();
		StringBuilder paramConstructorBody=new StringBuilder();
		StringBuilder defConstructorBody=new StringBuilder();
		String fieldName=null;
		StringBuilder valueBuilder=new StringBuilder();
		valueBuilder.append("class MyCustomValue implements Writable \n { \n");
		for(int i=0;i<fieldCount;i++)
		{
			fieldName="valField_"+i;
			fieldVector.add(fieldName);
			valueBuilder.append(DataType.TEXT+" "+fieldName+"=null;\n");
			if(null==paramConstructor)
			{
				paramConstructor=new StringBuilder();
				paramConstructor.append(DataType.JAVA_TEXT+" "+fieldName);
			}
			else
				paramConstructor.append(","+DataType.JAVA_TEXT+" "+fieldName);
			
			paramConstructorBody.append("this."+fieldName+"=new "+DataType.TEXT+"(" +fieldName+");\n");
			
			
			defConstructorBody.append(fieldName+"=new "+DataType.TEXT+"();\n");
		}
		/*
		 * Following code does the constructor part.Parameterized constructor
		 */
		valueBuilder.append("public MyCustomValue("+paramConstructor+")\n{\n");
		valueBuilder.append(paramConstructorBody.toString());
		valueBuilder.append("}\n");
		//end of parameterized constructor
		
		/*
		 * Following part does the default constructor
		 */
		valueBuilder.append("public MyCustomValue()\n{\n");
		valueBuilder.append(defConstructorBody.toString()+"\n}\n");
		//end of default constructor
		
		/*
		 * Following code creates getter,setter
		 */
		for(String field:fieldVector)
		{
			valueBuilder.append("public void set"+field+"("+DataType.TEXT+" "+field+")\n{\n");
			valueBuilder.append("this."+field+"="+field+";\n}\n");
			
			valueBuilder.append("public "+DataType.TEXT+" get"+field+"()\n{\n");
			valueBuilder.append("return "+field+";\n}\n");
		}
		//end of getter setters
		
		/*
		 * Following creates toString method
		 */
		

		valueBuilder.append("public String toString()\n{\n");
		cnt=0;//this is used to avoid append in for loop
		valueBuilder.append("return ");
		for(String field:fieldVector)
		{
			if(cnt==0)
				valueBuilder.append(field+".toString()");
			else
				valueBuilder.append("+"+field+".toString()");
			cnt++;
		}
		valueBuilder.append(";\n}\n");
		cnt=0;
		//end of tostring
		
		/*
		 * Following code reads data from readField
		 */
		valueBuilder.append("public void readFields(DataInput in) throws IOException {\n");
		for(String field:fieldVector)
		{
			valueBuilder.append(field+".readFields(in);\n");
		}
		valueBuilder.append("}\n");
		//end of readFields
		
		/*
		 * Following code write data from write
		 */
		valueBuilder.append("public void write(DataOutput out) throws IOException {\n");
		for(String field:fieldVector)
		{
			valueBuilder.append(field+".write(out);\n");
		}
		valueBuilder.append("}\n");
		//end of write
		
		valueBuilder.append("}");//to end main class curly brace
		return valueBuilder.toString();
	}

}
