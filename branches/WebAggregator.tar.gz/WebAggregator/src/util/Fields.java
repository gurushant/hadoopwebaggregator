package util;

public class Fields {
	private String inputPath,outputPath,splitSize,seperator,
	isSplitable,keys,values,sortMemory,minSpillForCombiner,numOfReducer;

	public String getInputPath() {
		return inputPath;
	}

	public void setInputPath(String inputPath) {
		this.inputPath = inputPath;
	}

	public String getOutputPath() {
		return outputPath;
	}

	public void setOutputPath(String outputPath) {
		this.outputPath = outputPath;
	}

	public String getSplitSize() {
		return splitSize;
	}

	public void setSplitSize(String splitSize) {
		this.splitSize = splitSize;
	}

	public String getSeperator() {
		return seperator;
	}

	public void setSeperator(String seperator) {
		this.seperator = seperator;
	}

	public String getIsSplitable() {
		return isSplitable;
	}

	public void setIsSplitable(String isSplitable) {
		this.isSplitable = isSplitable;
	}

	public String getKeys() {
		return keys;
	}

	public void setKeys(String keys) {
		this.keys = keys;
	}

	public String getValues() {
		return values;
	}

	public void setValues(String values) {
		this.values = values;
	}

	public String getSortMemory() {
		return sortMemory;
	}

	public void setSortMemory(String sortMemory) {
		this.sortMemory = sortMemory;
	}

	public String getMinSpillForCombiner() {
		return minSpillForCombiner;
	}

	public void setMinSpillForCombiner(String minSpillForCombiner) {
		this.minSpillForCombiner = minSpillForCombiner;
	}

	public String getNumOfReducer() {
		return numOfReducer;
	}

	public void setNumOfReducer(String numOfReducer) {
		this.numOfReducer = numOfReducer;
	}
	

}
