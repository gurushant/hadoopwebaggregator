package util;

public class DataType {
	public static final String TEXT="Text";
	public static final String JAVA_TEXT="String";
}
