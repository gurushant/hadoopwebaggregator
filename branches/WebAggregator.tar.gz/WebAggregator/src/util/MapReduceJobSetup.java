package util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.MRJobConfig;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class MapReduceJobSetup {

	public static final String SCRIPT_PATH="/home/gurushant/gurushant/scripts/";
	public static final String JAVA_CODE="/home/gurushant/gurushant/scripts/";
	public static final String COMPILE_RUN="/home/gurushant/gurushant/scripts/java_class/compile.sh";
	public static final String CLASS_NAME=JAVA_CODE+"java_class/MRDriver.java";
	private String hadoopPath=null;
	public static final String HADOOP_PATH="/home/gurushant/gurushant/data/personal/sw/hadoop-2.2.0/bin/";
	private String inputPath=null;
	private static String seperator=null,keys=null,values=null,reducerCnt=null;

	public HashMap<String, String> paramMap=null;
	public static void main(String[] args) throws Exception {

	}
	private void executeHadoopCommand(final String command)
	{
		
				ProcessBuilder process=new ProcessBuilder(command);
				try {
					System.out.println("Running...");
					process.start().waitFor();
					System.out.println("Finished...");
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

	}

	public String getHadoopPath()
	{
		return hadoopPath;
	}
	public static String getSeperator()
	{
		return seperator;
	}
	public static String getKeys()
	{
		return keys;
	}

	public static String getValues()
	{
		return values;
	}


	public HashMap<String, String> getParam()
	{
		return paramMap;
	}

	public String getJobName()
	{
		return hadoopPath;
	}
	
	private File createFile(String content,String name)
	{
		try
		{
			File file=new File(SCRIPT_PATH+name);
			file.createNewFile();
			file.setExecutable(true);
			file.setWritable(true);
			file.setReadable(true);

			FileOutputStream fout=new FileOutputStream(file);
			fout.write("#/bin/sh\n".getBytes());
			fout.write(content.getBytes());
			fout.close();
			return file;
		}
		catch(Exception ex)
		{

			ex.printStackTrace();
			return null;
		}
	}

	public void submitFile(HashMap<String, String> param)
	{
		try
		{
			paramMap=new HashMap<String, String>();
			hadoopPath=param.get("job_name");
			paramMap=(HashMap<String, String>) param.clone();
			File scriptFile=null;
			seperator=param.get("seperator");
			keys=param.get("keys");
			values=param.get("values");
			reducerCnt=param.get("no_of_reducer");

			inputPath=param.get("input_file");

			//remove existing file from hdfs
			scriptFile=createFile(HADOOP_PATH+"hdfs dfs -rm -r /data/"+param.get("file_name"), "remove.sh");
			hadoopPath="/data/"+param.get("file_name");
			executeHadoopCommand(scriptFile.getAbsolutePath());
			//put file in hdfs
			scriptFile=createFile(HADOOP_PATH+"hdfs dfs -put "+inputPath +" /data", "addFile.sh");
			executeHadoopCommand(scriptFile.getAbsolutePath());
			
			generateCode();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		
	}
	
	private void createTemplate()
	{
		try {
			byte buffer[]=null;
			FileInputStream fin=new FileInputStream(JAVA_CODE+"Template.java");
			FileOutputStream fout=new FileOutputStream(CLASS_NAME);
			
			buffer=new byte[fin.available()];
			while(fin.available() >0)
			{
				fin.read(buffer);
				fout.write(buffer);
			}
			fin.close();
			fout.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void generateCode()
	{
		createTemplate();
		System.out.println("param map="+getParam());
		writeToFile(new CustomMapper().createMapper(getParam()));
		writeToFile(new CustomKeyGenerator().createCustomKey(keys.split(",").length));
		writeToFile(new CustomValueGenerator().createCustomValue(values.split(",").length));
		/**
		 * Following code write params in class file, which are refferred in Mapper
		 */
		writeToFile("class PARAMS");
		writeToFile("{");
		writeToFile("public static final String SEPERATOR=\""+getSeperator()+"\";");
		writeToFile("public static final String KEYS=\""+getKeys()+"\";");
		writeToFile("public static final String VALUES=\""+getValues()+"\";");
		writeToFile("public static final String HADOOP_IN_PATH=\""+getHadoopPath()+"\";");
		writeToFile("public static final String HADOOP_OUT_PATH=\""+getJobName()+"\";");
		writeToFile("}");
		
		executeHadoopCommand(COMPILE_RUN);
	}

	private void writeToFile(String content)
	{
		try {
			FileOutputStream fout=new FileOutputStream(CLASS_NAME,true);
			fout.write("\n".getBytes());
			fout.write(content.getBytes());
			fout.write("\n".getBytes());
			fout.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	

}
