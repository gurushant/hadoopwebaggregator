package util;

import java.util.HashMap;


public class CustomMapper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	String createMapper(HashMap<String, String> param)
	{
		int cnt=0;
		String arr[]=null;
		StringBuilder strBuilder=new StringBuilder();
		StringBuilder tmpKeyBuilder=new StringBuilder();
		StringBuilder tmpValBuilder=new StringBuilder();
		
		strBuilder.append("class MyMapper extends Mapper<LongWritable, Text, MyCustomKey, MyCustomValue>");
		strBuilder.append("\n");
		strBuilder.append("{\n");
		strBuilder.append("public void map(LongWritable ikey, Text ivalue, Context context)"+
			"throws IOException, InterruptedException {\n");
		strBuilder.append("String seperator=\""+param.get("seperator")+"\";\n");
		strBuilder.append("String value[]=ivalue.toString().split(seperator);\n");
		strBuilder.append("String keys=\""+param.get("keys")+"\";\n");
		strBuilder.append("String values=\""+param.get("values")+"\";\n");
		arr=param.get("keys").split(",");
		cnt=arr.length;
		tmpKeyBuilder.append("new MyCustomKey(");
		for(int i=0;i<cnt;i++)
		{
			if(i==0)
				tmpKeyBuilder.append("value["+arr[i]+"]");
			else
				tmpKeyBuilder.append(",value["+arr[i]+"]");
		}
		tmpKeyBuilder.append(")");
		
		arr=param.get("values").split(",");
		cnt=arr.length;
		
		tmpValBuilder.append("new MyCustomValue(");
		for(int i=0;i<cnt;i++)
		{
			if(i==0)
				tmpValBuilder.append("value["+arr[i]+"]");
			else
				tmpValBuilder.append(",value["+arr[i]+"]");
		}
		tmpValBuilder.append(")");
		
		strBuilder.append("context.write("+tmpKeyBuilder+","+tmpValBuilder+");");
		strBuilder.append("}\n}\n");
		return strBuilder.toString();
	}
	

}
