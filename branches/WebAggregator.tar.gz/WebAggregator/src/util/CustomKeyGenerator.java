package util;
import java.util.Vector;


public class CustomKeyGenerator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new CustomKeyGenerator().createCustomKey(2);
	}
	
	String createCustomKey(int fieldCount)
	{
		StringBuilder paramConstructor=null;
		int cnt=0;
		Vector<String> fieldVector=new Vector<String>();
		StringBuilder paramConstructorBody=new StringBuilder();
		StringBuilder defConstructorBody=new StringBuilder();
		String fieldName=null;
		StringBuilder keyBuilder=new StringBuilder();
		keyBuilder.append("class MyCustomKey implements WritableComparable<MyCustomKey> \n { \n");
		for(int i=0;i<fieldCount;i++)
		{
			fieldName="keyField_"+i;
			fieldVector.add(fieldName);
			keyBuilder.append(DataType.TEXT+" "+fieldName+"=null;\n");
			if(null==paramConstructor)
			{
				paramConstructor=new StringBuilder();
				paramConstructor.append(DataType.JAVA_TEXT+" "+fieldName);
			}
			else
				paramConstructor.append(","+DataType.JAVA_TEXT+" "+fieldName);
			
			paramConstructorBody.append("this."+fieldName+"=new "+DataType.TEXT+"(" +fieldName+");\n");
			
			
			defConstructorBody.append(fieldName+"=new "+DataType.TEXT+"();\n");
		}
		/*
		 * Following code does the constructor part.Parameterized constructor
		 */
		keyBuilder.append("public MyCustomKey("+paramConstructor+")\n{\n");
		keyBuilder.append(paramConstructorBody.toString());
		keyBuilder.append("}\n");
		//end of parameterized constructor
		
		/*
		 * Following part does the default constructor
		 */
		keyBuilder.append("public MyCustomKey()\n{\n");
		keyBuilder.append(defConstructorBody.toString()+"\n}\n");
		//end of default constructor
		
		/*
		 * Following code creates getter,setter
		 */
		for(String field:fieldVector)
		{
			keyBuilder.append("public void set"+field+"("+DataType.TEXT+" "+field+")\n{\n");
			keyBuilder.append("this."+field+"="+field+";\n}\n");
			
			keyBuilder.append("public "+DataType.TEXT+" get"+field+"()\n{\n");
			keyBuilder.append("return "+field+";\n}\n");
		}
		//end of getter setters
		
		/*
		 * Following creates toString method
		 */
		
		keyBuilder.append("public String toString()\n{\n");
		cnt=0;//this is used to avoid append in for loop
		keyBuilder.append("return ");
		for(String field:fieldVector)
		{
			if(cnt==0)
			keyBuilder.append(field+".toString()");
			else
				keyBuilder.append("+"+field+".toString()");
			cnt++;
		}
		keyBuilder.append(";\n}\n");
		cnt=0;
		//end of tostring
		
		/*
		 * Following code reads data from readField
		 */
		keyBuilder.append("public void readFields(DataInput in) throws IOException {\n");
		for(String field:fieldVector)
		{
			keyBuilder.append(field+".readFields(in);\n");
		}
		keyBuilder.append("}\n");
		//end of readFields
		
		/*
		 * Following code write data from write
		 */
		keyBuilder.append("public void write(DataOutput out) throws IOException {\n");
		for(String field:fieldVector)
		{
			keyBuilder.append(field+".write(out);\n");
		}
		keyBuilder.append("}\n");
		//end of write
		/*
		 * Following code for compareTo method
		 */
		keyBuilder.append("public int compareTo(MyCustomKey key) {\n");
		keyBuilder.append("int res=0;\n");
		for(String field:fieldVector)
		{
			if(cnt >0)
			{
				keyBuilder.append("if(res==0)\n");
				keyBuilder.append("res="+field+".compareTo(key."+field+");\n");
			}
			else
			keyBuilder.append("res="+field+".compareTo(key."+field+");\n");
			cnt++;
		}
		keyBuilder.append("return res;\n");
		//end of comparaTo
		
		keyBuilder.append("}\n");
		keyBuilder.append("}");//to end main class curly brace
		return keyBuilder.toString();
	}

}
