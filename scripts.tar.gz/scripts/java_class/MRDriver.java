import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.yarn.webapp.Params;

public class MRDriver {

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		conf.set("mapreduce.cluster.local.dir", "/home/gurushant/gurushant");
		Job job = Job.getInstance(conf, "JobName");
		job.setJarByClass(MRDriver.class);
		// TODO: specify a mapper
		job.setMapperClass(MyMapper.class);
		job.setJobName("buzz");
		// TODO: specify a reducer
		//job.setReducerClass(Reducer.class);
		job.setMapOutputKeyClass(MyCustomKey.class);
		// TODO: specify output types
		job.setOutputKeyClass(MyCustomKey.class);
		job.setOutputValueClass(MyCustomValue.class);
		job.setNumReduceTasks(0);

		// TODO: specify input and output DIRECTORIES (not files)
		FileInputFormat.setInputPaths(job, new Path(PARAMS.HADOOP_IN_PATH));
		FileOutputFormat.setOutputPath(job, new Path("/data/out"));

		if (!job.waitForCompletion(true))
			return;
	}
}

class MyMapper extends Mapper<LongWritable, Text, MyCustomKey, MyCustomValue>
{
public void map(LongWritable ikey, Text ivalue, Context context)throws IOException, InterruptedException {
String seperator=",";
String value[]=ivalue.toString().split(seperator);
String keys="1";
String values="1";
context.write(new MyCustomKey(value[1]),new MyCustomValue(value[1]));}
}


class MyCustomKey implements WritableComparable<MyCustomKey> 
 { 
Text keyField_0=null;
public MyCustomKey(String keyField_0)
{
this.keyField_0=new Text(keyField_0);
}
public MyCustomKey()
{
keyField_0=new Text();

}
public void setkeyField_0(Text keyField_0)
{
this.keyField_0=keyField_0;
}
public Text getkeyField_0()
{
return keyField_0;
}
public String toString()
{
return keyField_0.toString();
}
public void readFields(DataInput in) throws IOException {
keyField_0.readFields(in);
}
public void write(DataOutput out) throws IOException {
keyField_0.write(out);
}
public int compareTo(MyCustomKey key) {
int res=0;
res=keyField_0.compareTo(key.keyField_0);
return res;
}
}

class MyCustomValue implements Writable 
 { 
Text valField_0=null;
public MyCustomValue(String valField_0)
{
this.valField_0=new Text(valField_0);
}
public MyCustomValue()
{
valField_0=new Text();

}
public void setvalField_0(Text valField_0)
{
this.valField_0=valField_0;
}
public Text getvalField_0()
{
return valField_0;
}
public String toString()
{
return valField_0.toString();
}
public void readFields(DataInput in) throws IOException {
valField_0.readFields(in);
}
public void write(DataOutput out) throws IOException {
valField_0.write(out);
}
}

class PARAMS

{

public static final String SEPERATOR=",";

public static final String KEYS="1";

public static final String VALUES="1";

public static final String HADOOP_IN_PATH="/data/city.txt";

public static final String HADOOP_OUT_PATH="/data/city.txt";

}
