#/bin/sh
/home/gurushant/gurushant/data/personal/sw/hadoop-2.2.0/bin/hdfs dfs -rm -r /data/city.txt