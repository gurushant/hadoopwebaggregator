#/bin/sh
/home/gurushant/gurushant/data/personal/sw/hadoop-2.2.0/bin/hdfs dfs -put /home/gurushant/gurushant/input_to_mr/city.txt /data