
class MyCustomKey implements WritableComparable<MyCustomKey> 
 { 
Text keyField_0=null;
Text keyField_1=null;
Text keyField_2=null;
public MyCustomKey(String keyField_0,String keyField_1,String keyField_2)
{
this.keyField_0=new Text(keyField_0);
this.keyField_1=new Text(keyField_1);
this.keyField_2=new Text(keyField_2);
}
public MyCustomKey()
{
keyField_0=new Text();
keyField_1=new Text();
keyField_2=new Text();

}
public void setkeyField_0(Text keyField_0)
{
this.keyField_0=keyField_0;
}
public Text getkeyField_0()
{
return keyField_0;
}
public void setkeyField_1(Text keyField_1)
{
this.keyField_1=keyField_1;
}
public Text getkeyField_1()
{
return keyField_1;
}
public void setkeyField_2(Text keyField_2)
{
this.keyField_2=keyField_2;
}
public Text getkeyField_2()
{
return keyField_2;
}
public String toString()
{
return keyField_0.toString()+keyField_1.toString()+keyField_2.toString();
}
public void readFields(DataInput in) throws IOException {
keyField_0.readFields(in);
keyField_1.readFields(in);
keyField_2.readFields(in);
}
public void write(DataOutput out) throws IOException {
keyField_0.write(out);
keyField_1.write(out);
keyField_2.write(out);
}
public int compareTo(MyCustomKey key) {
int res=0;
res=keyField_0.compareTo(key.keyField_0);
if(res==0)
res=keyField_1.compareTo(key.keyField_1);
if(res==0)
res=keyField_2.compareTo(key.keyField_2);
return res;
}
}

class MyCustomValue implements Writable 
 { 
Text valField_0=null;
Text valField_1=null;
public MyCustomValue(String valField_0,String valField_1)
{
this.valField_0=new Text(valField_0);
this.valField_1=new Text(valField_1);
}
public MyCustomValue()
{
valField_0=new Text();
valField_1=new Text();

}
public void setvalField_0(Text valField_0)
{
this.valField_0=valField_0;
}
public Text getvalField_0()
{
return valField_0;
}
public void setvalField_1(Text valField_1)
{
this.valField_1=valField_1;
}
public Text getvalField_1()
{
return valField_1;
}
public String toString()
{
return valField_0.toString()+valField_1.toString();
}
public void readFields(DataInput in) throws IOException {
valField_0.readFields(in);
valField_1.readFields(in);
}
public void write(DataOutput out) throws IOException {
valField_0.write(out);
valField_1.write(out);
}
}

class PARAMS

{

public static final String SEPERATOR="null";

public static final String KEYS="1,2,5";

public static final String VALUES="10,15";

public static final String HADOOP_IN_PATH="/data/city.txt";

}

class MyCustomKey implements WritableComparable<MyCustomKey> 
 { 
Text keyField_0=null;
Text keyField_1=null;
Text keyField_2=null;
public MyCustomKey(String keyField_0,String keyField_1,String keyField_2)
{
this.keyField_0=new Text(keyField_0);
this.keyField_1=new Text(keyField_1);
this.keyField_2=new Text(keyField_2);
}
public MyCustomKey()
{
keyField_0=new Text();
keyField_1=new Text();
keyField_2=new Text();

}
public void setkeyField_0(Text keyField_0)
{
this.keyField_0=keyField_0;
}
public Text getkeyField_0()
{
return keyField_0;
}
public void setkeyField_1(Text keyField_1)
{
this.keyField_1=keyField_1;
}
public Text getkeyField_1()
{
return keyField_1;
}
public void setkeyField_2(Text keyField_2)
{
this.keyField_2=keyField_2;
}
public Text getkeyField_2()
{
return keyField_2;
}
public String toString()
{
return keyField_0.toString()+keyField_1.toString()+keyField_2.toString();
}
public void readFields(DataInput in) throws IOException {
keyField_0.readFields(in);
keyField_1.readFields(in);
keyField_2.readFields(in);
}
public void write(DataOutput out) throws IOException {
keyField_0.write(out);
keyField_1.write(out);
keyField_2.write(out);
}
public int compareTo(MyCustomKey key) {
int res=0;
res=keyField_0.compareTo(key.keyField_0);
if(res==0)
res=keyField_1.compareTo(key.keyField_1);
if(res==0)
res=keyField_2.compareTo(key.keyField_2);
return res;
}
}

class MyCustomValue implements Writable 
 { 
Text valField_0=null;
Text valField_1=null;
public MyCustomValue(String valField_0,String valField_1)
{
this.valField_0=new Text(valField_0);
this.valField_1=new Text(valField_1);
}
public MyCustomValue()
{
valField_0=new Text();
valField_1=new Text();

}
public void setvalField_0(Text valField_0)
{
this.valField_0=valField_0;
}
public Text getvalField_0()
{
return valField_0;
}
public void setvalField_1(Text valField_1)
{
this.valField_1=valField_1;
}
public Text getvalField_1()
{
return valField_1;
}
public String toString()
{
return valField_0.toString()+valField_1.toString();
}
public void readFields(DataInput in) throws IOException {
valField_0.readFields(in);
valField_1.readFields(in);
}
public void write(DataOutput out) throws IOException {
valField_0.write(out);
valField_1.write(out);
}
}

class PARAMS

{

public static final String SEPERATOR="null";

public static final String KEYS="1,2,5";

public static final String VALUES="10,15";

public static final String HADOOP_IN_PATH="/data/city.txt";

}
